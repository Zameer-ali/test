<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>

<body>
    <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">Courses</a>
            <ul>
                <li><a href="#">PHP</a>
                    
                </li>
                <li><a href="#">Database</a></li>
                <li><a href="#">Java</a>
                    <ul class="sub-menu">
                        <li><a href="#">Advance</a></li>
                        <li><a href="#">Basic</a></li>
                    </ul>
                </li>

                <li><a href="#">Graphic Design</a></li>
                <li><a href="#">Networking</a></li>
            </ul>
        </li>
        <li><a href="#">FAQ</a></li>
        <li><a href="#">Help</a></li>
        <li><a href="#">About us</a></li>
        <li><a href="#">Contact us</a></li>
    </ul>
</body>

</html>