<!DOCTYPE html>
<html lang="en">

<head>
    <title> Dropdown Menu </title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <ul class="main-navigation">
        <li><a href="#">Home</a></li>
        <li><a href="#">Front End Design</a>
            <ul>
                <li><a href="#">HTML</a></li>
                <li><a href="#">CSS</a>
                    <ul>
                        <li><a href="#">Resets</a></li>
                        <li><a href="#">Grids</a></li>
                        <li><a href="#">Frameworks</a>
                            <ul>
                                <li><a href="#">Resets</a></li>
                                <li><a href="#">Grids</a></li>
                                <li><a href="#">Frameworks</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li><a href="#">JavaScript</a>
                    <ul>
                        <li><a href="#">Ajax</a></li>
                        <li><a href="#">jQuery</a></li>
                    </ul>
                </li>
            </ul>
        </li>
        <li><a href="#">WordPress Development</a>
            <ul>
                <li><a href="#">Themes</a></li>
                <li><a href="#">Plugins</a></li>
                <li><a href="#">Custom Post Types</a>
                    <ul>
                        <li><a href="#">Portfolios</a></li>
                        <li><a href="#">Testimonials</a></li>
                    </ul>
                </li>
                <li><a href="#">Options</a></li>
            </ul>
        </li>
        <li><a href="#">About Us</a></li>
    </ul>

</body>

</html>