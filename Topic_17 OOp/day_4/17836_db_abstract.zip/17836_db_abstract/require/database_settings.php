<?php 

	$hostname = "localhost";
	$username = "root";
	$password = "";
	$database = "hist_blog_management_system";

?>