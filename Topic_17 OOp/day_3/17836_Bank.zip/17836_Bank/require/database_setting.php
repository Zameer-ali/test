<?php 

 	$hostname = "localhost";
 	$username = "root";
 	$password = "";
 	$database_name = "za_bank";

	 
?>