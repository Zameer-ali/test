<?php 

 	$hostname = "localhost";
 	$username = "root";
 	$password = "";
 	$database_name = "hist_blog_management_system";



?>